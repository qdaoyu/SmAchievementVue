<template>
    <div>
        test2
    </div>
 
</template>
<script>
export default{
    name :"Test2"
}
</script>
<style scoped> 

</style>