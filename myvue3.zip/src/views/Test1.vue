<template>
    <div>
        test1
    </div>
    
</template>
<script>
export default{
    name :"Test1"
}
</script>
<style scoped>

</style>