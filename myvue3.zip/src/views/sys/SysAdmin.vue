<template>
    <div>
        操作员管理
    </div>
    
</template>
<script>
export default{
    name :"SysAdmin"
}
</script>
<style scoped>

</style>
