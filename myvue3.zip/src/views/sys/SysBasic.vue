<template>
    <div>
        基础信息管理
    </div>
    
</template>
<script>
export default{
    name :"SysBasic"
}
</script>
<style scoped>

</style>
