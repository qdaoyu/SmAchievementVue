<template>
    <div>
        基础信息
    </div>
    
</template>
<script>
export default{
    name :"UserBasic"
}
</script>
<style scoped>

</style>