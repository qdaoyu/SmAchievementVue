<template>
    <div>
        工资条查询
    </div>
    
</template>
<script>
export default{
    name :"AchiveSalSearch"
}
</script>
<style scoped>

</style>