<template>
    <div>
        业绩查询
    </div>
    
</template>
<script>
export default{
    name :"AchiveSearch"
}
</script>
<style scoped>

</style>