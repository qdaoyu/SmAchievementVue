<template>
    <div>
        绩效方案
    </div>
    
</template>
<script>
export default{
    name :"AchiveScheme"
}
</script>
<style scoped>

</style>