<template>
    <div>
        test3
    </div>
 
</template>
<script>
export default{
    name :"Test3"
}
</script>
<style scoped> 

</style>