<template>
    <div>
        可视乎看板导航
    </div>
    
</template>
<script>
export default{
    name :"DashboardNavigate"
}
</script>
<style scoped>

</style>
