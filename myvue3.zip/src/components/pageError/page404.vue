<template>
    <div>
      <h1>404错误，请检查地址是否有误</h1>
      <img src="@/assets/error_img/404.png">
    </div>
</template>
   
  <script>
  export default {
    name: "Page404",
  };
  </script>
   
  <!-- <style lang="less" scoped>
  
  </style> -->